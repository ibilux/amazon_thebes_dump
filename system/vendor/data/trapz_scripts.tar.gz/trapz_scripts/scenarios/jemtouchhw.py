from tablettouchbase import TabletTouchBaseStateMachine

class JemTouchHwStateMachine(TabletTouchBaseStateMachine):
    """See StateMachine base class in statemachine.py for documentation. It
    will make everything clear (or at least clearer)."""

    NAME = "JemTouchHw"
    DESCRIPTION = "Drawing states for FluidityLab application on Jem platform when running a hardware touch to draw test"


    def START__Touch_CypressTouchEvent(self,event):
        "A"
        self.hdwx = event.e1
        self.hdwy = event.e2
        return True

    def Touch_CypressTouchEvent__Touch_EvDevX(self,event):
        "A2"
        return self.hdwx == event.e1

    def Touch_EvDevX__Touch_EvDevY(self,event):
        "A3"
        return self.hdwy == event.e1

